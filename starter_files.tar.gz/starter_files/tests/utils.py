"""P3 utility functions."""
from pathlib import Path


# Directory containing unit tests.  Tests look here for input files.
TEST_DIR = Path(__file__).parent
